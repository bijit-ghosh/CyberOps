"""Offline defensive evaluation environments."""
