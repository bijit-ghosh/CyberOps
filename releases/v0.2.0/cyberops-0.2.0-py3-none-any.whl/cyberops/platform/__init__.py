"""CyberOps operator console."""
